<?php
include '../config.php';

$id = $_GET['id'];
$query = "SELECT title, file, file_type FROM ebooks WHERE id=$id";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

header("Content-Type: " . $row['file_type']);
header("Content-Disposition: attachment; filename=\"" . $row['title'] . ".docx\"");
echo $row['file'];
?>
