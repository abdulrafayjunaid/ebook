<?php
session_start();
include '../config.php';

$cart_items = $_SESSION['cart'] ?? [];

if (empty($cart_items)) {
    echo "<h2>Your cart is empty.</h2>";
    echo '<a href="index.php">Back to Library</a>';
    exit;
}

// Fetch ebooks from database
$ids = implode(",", array_map('intval', $cart_items));
$query = "SELECT id, title FROM ebooks WHERE id IN ($ids)";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
  <title>My Cart</title>
  <style>
    .download-link {
        display: none; /* hidden until payment */
    }
  </style>
</head>
<body>
  <h1>🛒 Your Cart</h1>
  <a href="index.php">⬅ Back to Library</a>
  <ul>
    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
      <li>
        <?php echo $row['title']; ?> 
        <a class="download-link" href="download.php?id=<?php echo $row['id']; ?>">Download</a>
      </li>
    <?php } ?>
  </ul>

  <h2>💳 Payment Form</h2>
  <form id="paymentForm" method="POST">
      <label>Name on Card:</label><br>
      <input type="text" name="name" required><br><br>

      <label>Card Number:</label><br>
      <input type="text" name="card" required><br><br>

      <label>Expiry:</label><br>
      <input type="text" name="expiry" placeholder="MM/YY" required><br><br>

      <label>CVV:</label><br>
      <input type="password" name="cvv" required><br><br>

      <button type="submit">Pay Now</button>
  </form>

  <script>
    const form = document.getElementById('paymentForm');
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        alert("✅ Payment successful!");
        
        // Show download buttons
        document.querySelectorAll('.download-link').forEach(link => {
            link.style.display = "inline";
        });

        // Hide payment form after payment
        form.style.display = "none";
    });
  </script>
</body>
</html>
