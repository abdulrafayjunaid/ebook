<?php
include '../config.php'; // database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $file = addslashes(file_get_contents($_FILES['ebook']['tmp_name']));
    $file_type = $_FILES['ebook']['type'];

    $query = "INSERT INTO ebooks (title, file, file_type) VALUES ('$title', '$file', '$file_type')";
    if (mysqli_query($conn, $query)) {
        echo "Ebook uploaded successfully!";
    } else {
        echo "Error: " . mysqli_error($con);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Upload Ebook</title>
</head>
<body>
  <h2>Upload Ebook (.docx)</h2>
  <form method="POST" enctype="multipart/form-data">
      <input type="text" name="title" placeholder="Enter ebook title" required><br><br>
      <input type="file" name="ebook" accept=".doc,.docx" required><br><br>
      <button type="submit">Upload</button>
  </form>
</body>
</html>
